# GoLang 01 talent Piscine solution

## How to contribute

1. Create a new branch
2. Commit your changes
3. Push to the branch
4. Create a new Pull Request

## Acknowledgments


## Author

