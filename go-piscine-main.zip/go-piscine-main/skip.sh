#!bin/bash
ls -l | sed -n '2~2p'
# utility link
# https://superuser.com/questions/852404/what-does-n-option-in-sed-do