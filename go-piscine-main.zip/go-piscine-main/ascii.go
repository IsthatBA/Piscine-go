package piscine

func Ascii(str string) []byte {
	return []byte(str)
}
