package piscine

func Sum(a, b string) int {
	return BasicAtoi(a) + BasicAtoi(b)
}
