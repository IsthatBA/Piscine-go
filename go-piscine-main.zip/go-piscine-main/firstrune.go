package piscine

func FirstRune(s string) rune {
	return []rune(s)[0]
}
