package piscine

func Enigma(a ***int, b *int, c *******int, d ****int) {
	x := *******c
	*******c = ***a
	y := ****d
	****d = x
	z := *b
	*b = y
	***a = z
}
