#   Revise
+   Swap
+   String Reverse
+   String Length
+   Print String
+   Recursive Factorial
+   Recursive Power
+   Fibonacci
+   Find Next Prime
#   All
+   pointone            ✅
+   ultimatepointone    ✅
+   divmod              ✅
+   ultimatedivmod      ✅
+   printstr            ✅
+   strlen              ✅
+   swap                ✅
+   strrev              ✅
+   basicatoi           ✅
+   basicatoi2          ✅
+   atoi                ✅
+   sortintegertable    ✅

+   iterativefactorial  ✅
+   recursivefactorial  ✅
+   iterativepower      ✅
+   recursivepower      ✅
+   fibonacci           ✅
+   sqrt                ✅
+   isprime             ✅
+   findnextprime       ✅
+   eightqueens         

+   firstrune           ✅
+   lastrune            ✅
+   nrune               ✅
+   compare             ✅
+   alphacount          ✅
+   index               ✅
+   concat              ✅
+   isupper             ✅
+   islower             ✅
+   isalpha             ✅
+   isnumeric           ✅
+   isprintable         ✅
+   toupper             ✅
+   tolower             ✅
+   printnbrinorder     ✅
+   trimatoi            ✅
+   capitalize          ✅
+   basicjoin           ✅
+   join
+   printnbrbase
+   atoibase

+   printprogramname
+   printparams
+   revparams
+   sortparams
+   nbrconvertalpha
+   flags
+   rotatevowels
