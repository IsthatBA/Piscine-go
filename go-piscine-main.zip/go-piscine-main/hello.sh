#!/bin/bash
echo "Hello mlazy!"
