package piscine

func BetweenUs(num, min, max int) bool {
	return min <= max && num >= min && num <= max
}
